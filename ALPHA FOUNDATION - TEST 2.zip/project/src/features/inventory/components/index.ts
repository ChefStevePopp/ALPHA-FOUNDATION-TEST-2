export { InventoryControl } from './InventoryControl';
export { InventoryTable } from './InventoryTable';