import React from 'react';

export const DiagnosticText: React.FC = () => {
  return (
    <div className="text-xs text-gray-500 font-mono mb-4">
      src/features/admin/components/sections/FoodRelationshipsManager/index.tsx
    </div>
  );
};