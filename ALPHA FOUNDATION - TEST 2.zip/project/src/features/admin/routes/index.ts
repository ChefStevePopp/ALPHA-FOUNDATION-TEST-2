import { AdminRoutes } from './AdminRoutes';
export { AdminRoutes };