// Export AdminRoutes from the routes directory
export { AdminRoutes } from './routes/AdminRoutes';